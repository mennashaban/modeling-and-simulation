﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LCG
{
    public partial class Form1 : Form
    {
        private DataGridView dataGridView1;
        private Panel panel1;
        public Form1()
        {
            InitializeComponent();
            

            // Initialize Panel to contain the DataGridView
            panel1 = new Panel();
            panel1.Dock = DockStyle.Fill;
            Controls.Add(panel1);

            // Initialize DataGridView within the Panel
            dataGridView1 = new DataGridView();
            dataGridView1.Dock = DockStyle.Fill;
            panel1.Controls.Add(dataGridView1);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Multi
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }




        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int multi = Convert.ToInt32(textBox1.Text);
            int seed = Convert.ToInt32(textBox2.Text);
            int c = Convert.ToInt32(textBox3.Text);
            int m = Convert.ToInt32(textBox4.Text);
            int iteration;
            // Check if textBox5.Text is not empty
            if (!string.IsNullOrEmpty(textBox5.Text))
            {
                // If not empty, try to convert to an integer; use 0 as a default if conversion fails
                int.TryParse(textBox5.Text, out iteration);
            }
            else
            {
                // If empty, use a default value (e.g., 0)
                iteration = 0;
            }

            // Create an instance of Form2
            Form2 form2 = new Form2(textBox6);

            // Call the Generate method on Form2
            int len = form2.Generate(multi, seed, c, m, iteration);
            textBox6.Text = len.ToString();
            // Show Form2
            form2.ShowDialog();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
