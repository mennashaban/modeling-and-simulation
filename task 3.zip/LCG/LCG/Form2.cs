﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LCG
{
    public partial class Form2 : Form
    {
        public Form2(TextBox textBox6)
        {
            InitializeComponent();

           
            // Initialize DataGridView within the Form
            dataGridView1 = new DataGridView();
            dataGridView1.Dock = DockStyle.Fill;
            Controls.Add(dataGridView1);

            // Add new columns to DataGridView
            dataGridView1.Columns.Add("IndexColumn", "Index");
            dataGridView1.Columns.Add("RandomNumberColumn", "Random Number");
        }

        public int CalculateGCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        public int Generate(int a, int seed, int c, int m, int num_iterations)
        {
            List<double> randomNumbers = new List<double>();
            int cycle_len = 0;
            int k = m - 1;
            if ((m & (m - 1)) == 0 && m != 0 && c != 0 && CalculateGCD(c, m) == 1 && (a - 1) % 4 == 0)
            {
                cycle_len = m;
                if (num_iterations == 0)
                {
                    for (int i = 0; i < cycle_len; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }
                else
                {
                    for (int i = 0; i < num_iterations; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }
            }
            else if ((m & (m - 1)) == 0 && m != 0 && c == 0 && seed % 2 != 0 && ((a - 5) % 8 == 0 || (a - 3) % 8 == 0))
            {
                cycle_len = m / 4;
                if (num_iterations == 0)
                {
                    for (int i = 0; i < cycle_len; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }
                else
                {
                    for (int i = 0; i < num_iterations; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }

            }
            else if (IsPrime(m) && c == 0 && (CalculatePower(a, m - 1, m) == 1))
            {
                cycle_len = m - 1;
                if (num_iterations == 0)
                {
                    for (int i = 0; i < cycle_len; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }
                else
                {
                    for (int i = 0; i < num_iterations; i++)
                    {
                        seed = (a * seed + c) % m;

                        double random = (double)seed / m;
                        randomNumbers.Add(random);

                    }
                }

            }

            else
            {

                int i = 0;
                while(true)
                {
                    seed = (a * seed + c) % m;

                    double random = (double)seed / m;
                    if (randomNumbers.Contains(random))
                    {
                        break;
                    }
                    else
                    {
                        randomNumbers.Add(random);
                    }
                    
                   

                    i++;
                    cycle_len++;

                }    
            }

            // Clear existing rows in DataGridView
            dataGridView1.Rows.Clear();

            // Populate DataGridView with index and randomNumbers
            for (int i = 0; i < randomNumbers.Count; i++)
            {
                dataGridView1.Rows.Add(i + 1, randomNumbers[i]);
            }


            return cycle_len;

        }

        private bool IsPrime(int n)
        {
            if (n <= 1)
                return false;

            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                    return false;
            }

            return true;
        }

        private int CalculatePower(int baseValue, int exponent, int modulus)
        {
            int result = 1;

            while (exponent > 0)
            {
                if (exponent % 2 == 1)
                    result = (result * baseValue) % modulus;

                baseValue = (baseValue * baseValue) % modulus;
                exponent = exponent / 2;
            }

            return result;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
